% % % % % % % % % % % % % % % % %
% % % % % UOB# 15026403 % % % % %
% % % % % % % % % % % % % % % % % 

data = csvread('breast-cancer-wisconsin.data');

% sorting of data
data=sortrows(data,11);
% total size of data
dataSize=size(data,1);

% counting healthy samples
benignCount=0;
for i=1:dataSize
    if data(i,11)==2
        benignCount=benignCount+1;
    end
end
% counting malignant samples
malignantCount=dataSize-benignCount;
% data without 11th column
data = data(:,2:10);
%divide input data into malignant and benignInput
benignInput=(data(1:benignCount,:));
malignantInput=(data(benignCount+1:dataSize,:));

%Data distribution based on percentage
trainingData=70;
validationData=30;

% counting benign and malignant for training
trainingBenignCount=ceil((benignCount*trainingData)/100);
trainingMalignantCount=ceil((malignantCount*trainingData)/100);

trainingInputData = [benignInput(1:trainingBenignCount,:)
    malignantInput(1:trainingMalignantCount,:)];
validationInputData =  [benignInput( trainingBenignCount+1: benignCount,:)
    malignantInput( trainingMalignantCount+1: malignantCount,:)];

% size of innput data for training
trainingInputSize=size(trainingInputData,1);
validationInputSize=size(validationInputData,1);

% array for training data output
trainingOutputData=zeros(trainingInputSize,2);
for i=(1:trainingInputSize)
    if (i<=trainingBenignCount)
        trainingOutputData(i,1)=1;
    else
        trainingOutputData(i,2)=1;
    end
end

validationOutputData=zeros(validationInputSize,2);
% validation output
for i=(1:validationInputSize)
    if (i<= benignCount-trainingBenignCount)
        validationOutputData(i,1)=1;
    else
        validationOutputData(i,2)=1;
    end
end



% % ########### ########### ###########
% % ########### Hypothesis Work ###########

%%% Hypothesis about number of neurons in hidden layer
% net = feedforwardnet(1000,'traingd');
% net = feedforwardnet(10000,'traingd');
% net = feedforwardnet(100,'traingd');
% net = feedforwardnet(10,'traingd');
% net = feedforwardnet(5,'traingd');


%%% Hypothesis about number of hidden layers
net = feedforwardnet([100, 10],'traingd');
% net = feedforwardnet([100, 50],'traingd');
% net = feedforwardnet([100, 50, 10],'traingd');
% net = feedforwardnet([100, 50, 10, 5],'traingd');

% % ########### Hypothesis ends ###########
% % ########### ########### ###########



[net,tr] = train(net,trainingInputData',trainingOutputData');
testing = sim(net,validationInputData');

% calculating accuracy of neural network
accCount=0;
for i=1:validationInputSize
    if testing(1,i)>testing(2,i) && validationOutputData(i,1) == 1
        accCount=accCount+1;
    end
    if  testing(1,i)<testing(2,i) && validationOutputData(i,2) == 1
           accCount=accCount+1;
   end
end
accuracy=(accCount/validationInputSize)*100